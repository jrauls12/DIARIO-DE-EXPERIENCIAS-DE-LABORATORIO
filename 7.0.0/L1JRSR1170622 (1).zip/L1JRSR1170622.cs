﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("iNGRESE SU NOMBRE:  ");
            string NOMBRE = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + NOMBRE);

            /*COMENTARIOS*/

            Console.Write("Hola Mundo");
            Console.Write("soy "  + NOMBRE);
            Console.ReadKey();
        }
    }
}
