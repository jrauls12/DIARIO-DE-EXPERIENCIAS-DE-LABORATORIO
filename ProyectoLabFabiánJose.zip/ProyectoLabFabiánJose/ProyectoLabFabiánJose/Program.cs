﻿using System;

namespace ProyectoLabFabiánJose
{
    class Program
    {
        static void Main(string[] args)
        {
            string usuario = "";
            Console.WriteLine("Este proyecto fue creado por José Solórzano(1170622)");
            Console.WriteLine(" y por Fabián Aragón(1070022)");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine(" Ingeniera ponganos un 10o porfaaaaa <3, nos costo mucho ;(");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Coloque el usuario: ");
            usuario = Console.ReadLine();
            Console.WriteLine("Bienvenido..... "+usuario);

            bool iniciarprograma = true;
            
            while (iniciarprograma == true)
            {
                Console.WriteLine("-----------------");
                Console.WriteLine("1:Panel de control");
                Console.WriteLine("2: Apagar");
                int opcion = int.Parse(Console.ReadLine());
                switch(opcion)
                {
                    case 1:
                        Console.WriteLine("Bienvenido al panel de control");
                        Console.WriteLine("------------------------------");
                        Console.WriteLine("Selecciona la opción de tu preferencia");
                        Console.WriteLine("1. Configuracion Ventilación");
                        Console.WriteLine("2. Configuracion Calefacción");
                        Console.WriteLine("3. Configuracion iluminacion");
                        Console.WriteLine("4.Apagar");
                        int opcion1 = int.Parse(Console.ReadLine());
                        switch (opcion1)
                        {
                            case 1:
                                VentilacionAuto();
                                break;
                            case 2:
                                Temperaturahabs();
                                break;
                            case 3:
                                Iluminacion();
                                break;
                            case 4:
                                Environment.Exit(0);
                                break;
                        }
                        break;
                    case 2:
 
                        Environment.Exit(0);
                        break;
                }
            }
            void VentilacionAuto()
            {
                double Hum = 0;
                do
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    Console.Write("Ingrese la humedad de las habitaciónes: ");
                    Hum = double.Parse(Console.ReadLine());
                    
                    if (Hum > 70)
                    {
                        Console.WriteLine("La humedad exede el 70%");
                    }
                }
                while (Hum > 70);

                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.Write("Ingrese las horas de ventilacion de las 4 habitaciones como enteeros");
                int[] horasinicio = new int[4];
                for (int i = 0; i <= 3; i++)
                {
                    
                    Console.WriteLine("Inicio de la hora de la ventilacion de la habitacion No.0"+(i+1));
                    horasinicio[i] = int.Parse(Console.ReadLine());
                    Console.WriteLine("Guardado...........................");

                }
                Console.WriteLine("se guardo la informaciond e las horas de inicio..........");
                Console.ReadKey();
                int[] horasfin = new int[4];
                for (int j = 0; j <= 3; j++)
                {
                    Console.WriteLine("Fin de la hora de la ventilacion de la habitacion No.0"+(j+1));
                    horasfin[j] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine("se guardo la informaciond de las horas de apagado..........");
                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine("Dé enter apra guardar la información");
                Console.WriteLine("----------------------------------------------------------");
                Console.ReadKey();
                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine("SE GUARDO TODA LA INFORMACION............");
                Console.ReadKey();
            }

            //void de temperatura
            void Temperaturahabs()
            {
                int promediotempmin = 0;
                int promediotempmax = 0;
                int suma = 0;
                int suma1 = 0;
               
                int[] HabMin = new int[4];
                int[] HabMax = new int[4];
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine("Ingresa las temperaturas de tus habitaciones");
                Console.WriteLine("---------------------------------------------");
               


                for (int i = 0; i <= 3; i++)
                {
                    
                    do
                    {

                       
                        Console.WriteLine("Temperatura minima de la Habitación No."+(i+1));
                        Console.WriteLine("---------------------------------------------");
                        HabMin[i] = int.Parse(Console.ReadLine());
                        if (HabMin[i] < 18)
                        {
                            Console.WriteLine("La temperatura minima de la habitación debe de ser de 18°C,vuelve a intentarlo");
                        }
                        Console.WriteLine();

                        Console.WriteLine("---------------------------------------------");
                        Console.WriteLine("---------------------------------------------");
                    } while (HabMin[i] < 18);


                }
                Console.WriteLine("Se guardaron los cambios.................");
                for (int h = 0; h <= 3; h++)
                {
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("Temperatura maxima de la Habitación No."+(1+h));
                    HabMax[h] = int.Parse(Console.ReadLine());
                }

                Console.WriteLine("-----------------------------------------------------");
                Console.WriteLine("Las temperaturas son:");
                Console.WriteLine("--------------------------------------------------");
                Console.WriteLine("-----------------------------------------------------");
                for (int i = 0; i <= 3; i++)
                {

                    Console.WriteLine("Las temperaturas Minima de la Habitacion No.0" + (1+i) + " son " + HabMin[i] + "C°");
                }
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                for (int h = 0; h <= 3; h++)
                {

                    Console.WriteLine("Las temperaturas maximas de la Habitacion No.0" + (h+1) + " son " + HabMax[h] + "C°");
                }

                for (int i = 0; i <= 3; i++)
                {
                    suma = suma + HabMin[i];
                    promediotempmin = suma;
                }

                Console.WriteLine("el promedio de las temperaturas minimas de las 4 habitaciones es" + (promediotempmin / 4));
                for (int h = 0; h <= 3; h++)
                {
                    suma1 = suma1 + HabMax[h];
                    promediotempmax = suma1;
                }
                Console.WriteLine("el promedio de las temperaturas maximas de las 4 habitaciones es" + (promediotempmax / 4));

            }
            Console.ReadKey();
            void Iluminacion()
            {
                Random generador = new Random();
                
                Console.WriteLine("No puede configurar la iluminación.");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("ESTADO:::::");
                int numero = generador.Next(1, 1000);
                bool espar = numero % 2 == 0;

                for (int h = 0; h <= 4; h++)
                {
                    if (espar)
                    {
                        Console.WriteLine("Si hay una persona en la habitacion");
                    }
                    else
                    {
                        Console.WriteLine("No hay una persona en la habitacion");
                    }

                }
                Console.ReadKey();
            }
        }
       
    }

    
}
