﻿using System;

namespace LAB16_JRSR_1170622
{
    class Program
    {
        static void Main(string[] args)
        {
            string opcion = "";
            Console.WriteLine("no sabia si el usuario debia meter los valores o si los teniamso que generar, asi que lo hice de las dos maneras");
            Console.WriteLine("Opción 1: ingresar los numeros");
            Console.WriteLine("Opción 2: generrar los numeros aleatoriamente");
            opcion = Console.ReadLine();
            switch (opcion)
                {
                case ("1"):
                    int valores2 = 0;
                    int numeros2;
                    int[,] matriz1 = new int[2, 2];
                    for (int f = 0; f < 40; f++)
                    {
                        for (int c = 0; c < 50; c++)
                        {
                            Console.WriteLine("ingresa los numeros");
                            numeros2 = int.Parse(Console.ReadLine());
                            matriz1[f, c] = numeros2;
                            valores2 = valores2 + matriz1[f, c];
                        }
                    }

                    Console.WriteLine("La suma de la matriz fue de: " + valores2);
                    break;
                case ("2"):
                    int suma1 = 0;                   
                    Random num = new Random();

                    int[,] matriz = new int[40, 50];
                    for (int f = 0; f < 40; f++)
                    {
                        for (int c = 0; c < 50; c++)
                        {
                            matriz[f, c] = num.Next(10);
                            suma1 = suma1 + matriz[f, c];
                        }
                    }
                    
                    Console.WriteLine("La suma de la matriz fue de: " + suma1);
                    int[,] matriz2 = new int[40, 50];
                    for (int f = 0; f < 40; f++)
                    {
                        for (int c = 0; c < 50; c++)
                        {
                            matriz2[f, c] = num.Next(10);
                        }

                    }
                    int[,] matriz3 = new int[40, 50];
                    for (int f = 0; f < 40; f++)
                    {
                        for (int c = 0; c < 50; c++)
                        {
                            matriz3[f, c] = matriz[f, c] + matriz2[f, c];
                            Console.Write(matriz3[f, c] + " ");
                        }
                        Console.WriteLine();
                    }

                    break;
            }

            
                

            }
            }
            
    }

