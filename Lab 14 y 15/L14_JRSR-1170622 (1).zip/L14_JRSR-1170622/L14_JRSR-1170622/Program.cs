﻿string opcion;
Console.WriteLine("Bienvenido al menu del laboratorio numero 14, por favor elije una opcion");
Console.WriteLine("Opción 1: Ingresar el nombre de 5 empleados, los cuales debe almacenar\r\nen un vector, después de ingresar los nombres debe ingresar la fecha de\r\nnacimiento, también deben de almacenarse en un vector, de cada uno de\r\nlos 5 empleados y calcular su edad al día de hoy. ");
Console.WriteLine("Opción 2: Ingresar el nombre de 5 puestos dentro una empresa, los cuales\r\ndebe almacenar un vector y también debe de almacenar el salario a pagar\r\nen cada uno de los puestos. ");
Console.WriteLine("Opción 3: Salir del programa");
Console.WriteLine("escribe 1,2 o 3 segun sea tu opcion");
opcion=Console.ReadLine();
{

}
switch(opcion)
{
    case "1":
        string[] nom = new string[5];
        int[] año = new int[5];
        int presente = 2022;
        for (int i = 0; i < 5; i++)
        {

            
            Console.WriteLine("Ingrese los nombres de los empleados");
            nom[i] = Console.ReadLine();
            Console.WriteLine("Ingrese el año en que nacio la persona");
            año[i] = int.Parse(Console.ReadLine());
        }
        int edad=0;
        for (int i = 0; i < 5; i++)
        {
            edad = presente - año[i];
            Console.WriteLine("la edad de " + nom[i]+ " es de "+edad);
            
        }

        break;
    case "2":
        string[] nom1 = new string[5];
        double[] sueldos = new double[5];
        
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("Ingrese los puestos");
            nom1[i] = Console.ReadLine();
            Console.WriteLine("Ingrese los sueldos de los puestos");
            sueldos[i] = int.Parse(Console.ReadLine());
        }
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("el puesto " + nom1[i]+ " recibe de sueldo " + sueldos[i]);
        }
        break;
    case "3":
        Console.WriteLine("Saldra del programa");
        Environment.Exit(0);
        break;
}
